class Item:
    def __init__(self):
        self.name = ""
        self.source = None
        self.producible = False  